<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="bg-white">
    <?php echo $__env->yieldContent('content'); ?>
</body>

</html>
<?php /**PATH D:\New folder\CodesCandy\DashUI\dashui-laravel-bootstrap-admin-template\resources\views/layouts/blank.blade.php ENDPATH**/ ?>