<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?> | Dash Ui - Bootstrap 5 Admin Dashboard Template</title>
    
    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/scss/theme.scss' ]); ?>
</head><?php /**PATH D:\New folder\CodesCandy\DashUI\dashui-free-laravel\resources\views\layouts\head.blade.php ENDPATH**/ ?>