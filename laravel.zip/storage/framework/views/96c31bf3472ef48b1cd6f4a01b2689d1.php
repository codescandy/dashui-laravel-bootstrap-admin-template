<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="bg-light">
    <div id="app">
        <div id="db-wrapper">
            <!-- navbar vertical -->            
            <?php echo $__env->make('layouts.navbar-vertical', ['page' => (isset($page)? $page : ''), 'page_group' => (isset($page_group)? $page_group : '')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Page content -->
            <div id="page-content">
                <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['node_modules/bootstrap/dist/js/bootstrap.bundle.min.js']); ?>
        
    </div>
</body>
</html>
<?php /**PATH D:\New folder\CodesCandy\DashUI\dashui-free-laravel\resources\views/layouts/default.blade.php ENDPATH**/ ?>