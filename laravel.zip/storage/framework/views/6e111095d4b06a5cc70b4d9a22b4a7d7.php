<?php $__env->startSection('title'); ?>
    Sign In
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container d-flex flex-column">
        <div class="row align-items-center justify-content-center g-0 min-vh-100">
            <div class="col-12 col-md-8 col-lg-6 col-xxl-4 py-8 py-xl-0">
                <!-- Card -->
                <div class="card smooth-shadow-md">
                    <!-- Card body -->
                    <div class="card-body p-6">
                        <div class="mb-4">
                            <a href="/"><img src="<?php echo e(Vite::asset('resources/images/brand/logo/logo-primary.svg')); ?>" alt="" /></a>
                            <p class="mb-6">Please enter your user information.</p>
                        </div>
                        <!-- Form -->
                        <form action="/">
                            <!-- Username -->
                            <div class="mb-3">
                                <label for="email" class="form-label"><?php echo e(__('Username or email')); ?></label>
                                <input id="email" type="email" class="form-control" autocomplete="email" autofocus>                               
                            </div>
                            <!-- Password -->
                            <div class="mb-3">
                                <label for="password" class="form-label"><?php echo e(__('Password')); ?></label>
                                <input id="password" type="password" class="form-control"autocomplete="current-password">                               
                            </div>
                            <!-- Remember Me Checkbox -->
                            <div class="d-lg-flex justify-content-between align-items-center mb-4">
                                <div class="form-check custom-checkbox">
                                    <input class="form-check-input" type="checkbox" id="remember">
                                    <label class="form-check-label" for="remember">Remember Me</label>
                                </div>
                            </div>
                            <div>
                                <!-- Sign in Button -->
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">Sign in</button>
                                </div>
                                <div class="d-md-flex justify-content-between mt-4">
                                    <div class="mb-2 mb-md-0">
                                        <a href="/sign-up" class="fs-5"><?php echo e(__('Create An Account')); ?></a>
                                    </div>
                                    <div>
                                            <a class="text-inherit" href="/forget-password">
                                                <?php echo e(__('Forgot Your Password?')); ?>

                                            </a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.blank', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\CodesCandy\DashUI\dashui-free-laravel\resources\views\sign-in.blade.php ENDPATH**/ ?>