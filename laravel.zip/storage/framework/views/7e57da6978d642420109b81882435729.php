<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="bg-light">
    <?php echo $__env->yieldContent('content'); ?>
</body>

</html>
<?php /**PATH D:\New folder\CodesCandy\DashUI\dashui-free-laravel\resources\views\layouts\blank.blade.php ENDPATH**/ ?>