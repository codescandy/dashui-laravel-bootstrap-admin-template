<?php $__env->startSection('title'); ?>
Overview
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
      <!-- Container fluid -->
      <div class="container-fluid p-6">
        <div class="row">
          <div class="col-lg-12 col-md-12 col-12">
            <!-- Page header -->
         
              <div class="border-bottom pb-4 mb-4">
              
                  <h3 class="mb-0 fw-bold">Billing</h3>

                
                
                </div>
             
            </div>
          </div>
        
        <!-- row  -->
        <div class="row mt-6">
          <div class="offset-xl-2 col-xl-8 offset-lg-1 col-lg-10 col-md-12
              col-12">
            <div class="row">
              <div class="col-12 mb-6">
                <!-- card  -->
                <div class="card">
                  <!-- card header  -->
                  <div class="card-header p-4 bg-white">
                    <h4 class="mb-0">Current Plan Overview</h4>
                  </div>
                  <!-- card body  -->
                  <div class="card-body">
                    <!-- row  -->
                    <div class="row">
                      <div class="col-xl-8 col-lg-6 col-md-12 col-12">
                        <div class="mb-2">
                          <!-- content  -->
                          <p class="text-muted mb-0">Current Plan</p>
                          <h3 class="mt-2 mb-3 fw-bold">Starter - Jan 2021 </h3>
                          <p>Unlimited access to essential tools for design, bootstrap themes, illustrator and icons.
                          </p>
                          <p><i data-feather="info" class="me-2 text-muted
                                icon-xs"></i>Next Payment: on <span class="text-primary">$499.00 USD</span><span class="text-dark fw-bold"> Jan 1, 2022</span></p>
                        </div>
                      </div>
                      <!-- col  -->
                      <div class="col-xl-4 col-lg-6 col-md-12 col-12">
                        <!-- content  -->
                        <div>
                          <small class="text-muted">
                              Yearly Payment
                            </small>
                          <h1 class="fw-bold text-primary">$499 USD</h1>
                          <a href="#" class="mb-3 text-muted
                              text-primary-hover d-block">Learn more about our
                              membership
                              policy</a>
                          <a href="#" class="btn btn-dark d-grid mb-2" data-bs-toggle="modal" data-bs-target="#planModal">
                              Change Plan
                            </a>
                          <a href="#" class="btn btn-outline-white d-grid">
                              Cancel Subscription
                            </a>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- card footer  -->
                  <div class="card-footer bg-white">
                    <div class="d-md-flex justify-content-between
                        align-items-center">
                      <!-- text  -->
                      <div class="mb-3 mb-lg-0 text-center text-sm-start">
                        <h5 class="text-uppercase mb-0">Payment method</h5>
                        <div class="mt-2">
                          <img src="../assets/images/creditcard/mastercard.svg" alt=""> <span class="fw-bold">***8773</span>
                        </div>
                      </div>
                      <div class="text-center text-md-start">
                        <a href="#" class="link-danger">Remove</a>
                        <a href="#" class="btn btn-outline-white ms-2">Change
                            Card</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12 mb-6">
                <!-- card  -->
                <div class="card">
                  <!-- card header  -->
                  <div class="card-header p-4 bg-white">
                    <h4 class="mb-0">Billing address</h4>
                  </div>
                  <!-- card body  -->
                  <div class="card-body">
                    <div class="row align-items-center">
                      <div class="col-lg-6 col-md-12 col-12 mb-4 mb-lg-0">
                        <div class="mb-3 mb-lg-0">
                          <!-- radio  -->
                          <div class="form-check ">
                            <input type="radio" id="shippingBillingAddress" name="customRadio" class="form-check-input" checked>
                            <label class="form-check-label" for="shippingBillingAddress">
                                <span class="d-block mb-3 text-dark
                                  fw-bold">Shipping Billing Address
                                </span>
                                <span class="d-block text-dark
                                  fw-medium fs-4">Valarie
                                  Tarrant</span>
                                <span class="d-block mb-4">3757 Morgan Street
                                  Tallahassee, FL 32301</span>
                                <a href="#" class="me-2 link-success">Edit</a>
                                <a href="#" class="me-2 link-danger">Delete</a>
                                <a href="#" class="me-2 text-muted
                                  text-primary-hover">Remove as Default Billing</a>
                              </label>
                          </div>
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-12 col-12 d-flex
                          justify-content-lg-end">
                        <!-- text  -->
                        <div class="mb-2">
                          <p class="mb-1">E-mail: <a href="#">valarietarrant@dashui.com</a></p>
                          <p>Phone: 321-654-0987</p>
                        </div>
                      </div>
                      <div class="col-12">
                        <!-- hr  -->
                        <hr class="my-6">
                      </div>
                      <div class="col-lg-6 col-md-12 col-12 mb-4 mb-lg-0">
                        <!-- radio  -->
                        <div class="form-check ">
                          <input type="radio" id="customRadio2" name="customRadio" class="form-check-input">
                          <label class="form-check-label" for="customRadio2">
                              <span class="d-block mb-3 text-dark
                                fw-bold">Default Billing Address
                              </span>
                              <span class="d-block text-dark fw-medium
                                fs-4">Mildred Cantu</span>
                              <span class="d-block mb-4">3757 Morgan Street
                                Tallahassee, FL 32301</span>
                              <a href="#" class="me-2 link-success">Edit</a>
                              <a href="#" class="me-2 link-danger">Delete</a>
                              <a href="#" class="me-2 text-muted
                                text-primary-hover">Set as Default</a>
                            </label>
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-12 col-12 d-flex
                          justify-content-lg-end">
                        <!-- text  -->
                        <div class="mb-2">
                          <p class="mb-1">E-mail: <a href="#">valarietarrant@dashui.com</a></p>
                          <p>Phone: 321-654-0987</p>
                        </div>
                      </div>
                      <div class="col-12">
                        <!-- hr  -->
                        <hr class="mt-6 mb-4">
                      </div>
                      <div class="col-12">
                        <!-- button  -->
                        <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#billingAddressModal">Add New Address</a>
                      </div>
                    </div>
                  </div>

                </div>
              </div>

            </div>
          </div>
        </div>


      </div>
    </div>

  </div>
  <!-- update plan modal -->
  <div class="modal fade" id="planModal" tabindex="-1" aria-labelledby="planModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">
        <div class="modal-header p-3">
          <div>
            <h4 class="mb-0" id="planModalLabel">Update Your Plan</h4>
          </div>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">

            </button>
        </div>
        <div class="modal-body p-5">
          <h4 class="mb-1">Change your plan</h4>
          <p>You can choose from one of the available plans bellow.</p>
          <div class="card border shadow-none">
            <div class="card-body border-bottom">
              <div class="d-flex justify-content-between
                  align-items-center">
                <div>
                  <div class="form-check ">
                    <input type="radio" id="customRadioStandard" name="customRadio" class="form-check-input">
                    <label class="form-check-label form-label" for="customRadioStandard">
                        <span class="d-block text-dark fw-bold">Standard
                          <span class="badge bg-success">Active Plan</span></span>
                        <span class="mb-0 small text-muted">Single Site</span>
                      </label>
                  </div>
                </div>
                <div>
                  <h4 class="fw-bold mb-0 text-dark">$49.00</h4>
                </div>
              </div>
            </div>
            <div class="card-body border-bottom">
              <div class="d-flex justify-content-between
                  align-items-center">
                <div>
                  <div class="form-check ">
                    <input type="radio" id="customRadioMultiside" name="customRadio" class="form-check-input">
                    <label class="form-check-label form-label" for="customRadioMultiside">
                        <span class="d-block text-dark fw-bold">Multiside
                        </span>
                        <span class="mb-0 small text-muted">Unlimited
                          sites</span>
                      </label>
                  </div>
                </div>
                <div>
                  <h4 class="fw-bold mb-0 text-dark">$149.00</h4>
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="d-flex justify-content-between
                  align-items-center">
                <div>
                  <div class="form-check ">
                    <input type="radio" id="customRadioExtended" name="customRadio" class="form-check-input">
                    <label class="form-check-label form-label" for="customRadioExtended">
                        <span class="d-block text-dark fw-bold">Extended
                        </span>
                        <span class="mb-0 small text-muted">For spanaying
                          users</span>
                      </label>
                  </div>
                </div>
                <div>
                  <h4 class="fw-bold mb-0 text-dark">$449.00</h4>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer justify-content-start p-5">
          <button type="button" class="btn btn-primary">Save and
              Continue</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
  <!-- Billing Address Modal -->
  <div class="modal fade" id="billingAddressModal" tabindex="-1" aria-labelledby="billingAddressModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">
        <div class="modal-header p-5">
          <div>
            <h4 class="mb-1" id="billingAddressModalLabel">Billing Address
            </h4>
            <p class="mb-0">Please provide the billing address with the credit card you ve provided.</p>
          </div>

          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">

          </button>
        </div>
        <div class="modal-body p-5">
          <form class="row">
            <div class="mb-3 col-12">
              <label for="country" class="form-label">Country</label>
              <select class="form-select" id="country">
                <option selected>India</option>
                <option value="US">US</option>
                <option value="UK">UK</option>
                <option value="UAE">UAE</option>
              </select>

            </div>
            <div class="mb-3 col-12">
              <label for="addressOne" class="form-label">Address line 1</label>
              <input type="text" class="form-control" placeholder="123 Ocean Ave" id="addressOne" required>

            </div>
            <div class="mb-3 col-12">
              <label for="addressTwo" class="form-label">Address line 2</label>
              <input type="text" class="form-control" placeholder="123 Ocean Ave" id="addressTwo" required>

            </div>
            <div class="mb-3 col-12">
              <label for="city" class="form-label">City</label>
              <select class="form-select" id="city">
                <option selected>Ahmedabad</option>
                <option value="New York">New York</option>
                <option value="Los Angeles">Los Angeles</option>
                <option value="Chicago">Chicago</option>
              </select>

            </div>
            <div class="mb-3 col-md-6 col-12">
              <label for="state" class="form-label">State</label>
              <input class="form-control" type="text" placeholder="Gujarat" id="state" required>
            </div>
            <div class="mb-3 col-md-6 col-12">
              <label for="zipCode" class="form-label">Zip/Postal Code</label>
              <input class="form-control" type="text" placeholder="000000" id="zipCode" required>
            </div>
            <div class="col-12 mb-3">
              <div class="form-check custom-checkbox">
                <input type="checkbox" class="form-check-input" id="customCheckAddress">
                <label class="form-check-label" for="customCheckAddress">Make this my default payment
                  method.</label>
              </div>
            </div>
            <div class="col-12">
              <button type="submit" class="btn btn-primary d-grid">Save
                Address</button>

            </div>
          </form>
        </div>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', ['page' => 'billing','page_group' => 'pages'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\CodesCandy\DashUI\dashui-laravel-bootstrap-admin-template\resources\views/billing.blade.php ENDPATH**/ ?>