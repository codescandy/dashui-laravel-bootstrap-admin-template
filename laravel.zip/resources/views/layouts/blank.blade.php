@include('layouts.head')

<body>
    @yield('content')
</body>

</html>
